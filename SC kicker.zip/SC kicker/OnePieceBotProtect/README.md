Bot Potect Group Line ONE PIECE Version
Siapkan 10 Akun Line 1 Akun Utama & 9 Akun Bot

Edit² Sedikit Token dan Mid Kalian

Dibutuhkan Install :

- pip install rsa
- pip install request
- pip install thrift==0.9.3
